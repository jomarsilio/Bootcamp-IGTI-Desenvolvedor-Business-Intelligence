--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.7
-- Dumped by pg_dump version 10.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP TABLE public.viagem;
DROP TABLE public.trecho;
DROP TABLE public.passagem;
DROP TABLE public.pagamento;
DROP TABLE public.cgu;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: cgu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cgu (
    "CÓDIGO ÓRGÃO" bigint,
    "nome_orgÃo" character varying(54),
    "ANO EXTRATO" bigint,
    "MÊS EXTRATO" bigint,
    "NOME FAVORECIDO" character varying(60),
    "DATA TRANSAÇÃO" timestamp without time zone,
    "VALOR TRANSAÇÃO" numeric(8,2)
);


ALTER TABLE public.cgu OWNER TO postgres;

--
-- Name: pagamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pagamento (
    idviagem bigint,
    orgao_superior character varying(22),
    orgao_pagador character varying(43),
    unidade_gestora character varying(39),
    tipo_pagamento character varying(30),
    valor numeric(9,2)
);


ALTER TABLE public.pagamento OWNER TO postgres;

--
-- Name: passagem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.passagem (
    idviagem bigint,
    transporte character varying(5),
    "pais_Origem ida" character varying(11),
    pais_destino character varying(11),
    valor_passagem numeric(9,2),
    taxaservico numeric(6,2)
);


ALTER TABLE public.passagem OWNER TO postgres;

--
-- Name: trecho; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trecho (
    id bigint,
    "Data" timestamp without time zone,
    "origem_país" character varying(6),
    "Origem _UF" character varying(17),
    "destino_país" character varying(6),
    destino_uf character varying(17),
    transporte character varying(15),
    diarias numeric(4,1),
    missao character varying(3)
);


ALTER TABLE public.trecho OWNER TO postgres;

--
-- Name: viagem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.viagem (
    "Id_processo_ viagem" bigint,
    situacao character varying(13),
    orgao_superior character varying(41),
    orgao_solicitante character varying(64),
    nome character varying(39),
    cargo character varying(37),
    data_inicio timestamp without time zone,
    data_fim timestamp without time zone,
    destinos character varying(33),
    motivo character varying(348),
    valor_diarias numeric(8,2),
    valor_passagens numeric(9,2)
);


ALTER TABLE public.viagem OWNER TO postgres;

--
-- Data for Name: cgu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cgu ("CÓDIGO ÓRGÃO", "nome_orgÃo", "ANO EXTRATO", "MÊS EXTRATO", "NOME FAVORECIDO", "DATA TRANSAÇÃO", "VALOR TRANSAÇÃO") FROM stdin;
\.
COPY public.cgu ("CÓDIGO ÓRGÃO", "nome_orgÃo", "ANO EXTRATO", "MÊS EXTRATO", "NOME FAVORECIDO", "DATA TRANSAÇÃO", "VALOR TRANSAÇÃO") FROM '$$PATH$$/2806.dat';

--
-- Data for Name: pagamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pagamento (idviagem, orgao_superior, orgao_pagador, unidade_gestora, tipo_pagamento, valor) FROM stdin;
\.
COPY public.pagamento (idviagem, orgao_superior, orgao_pagador, unidade_gestora, tipo_pagamento, valor) FROM '$$PATH$$/2807.dat';

--
-- Data for Name: passagem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.passagem (idviagem, transporte, "pais_Origem ida", pais_destino, valor_passagem, taxaservico) FROM stdin;
\.
COPY public.passagem (idviagem, transporte, "pais_Origem ida", pais_destino, valor_passagem, taxaservico) FROM '$$PATH$$/2808.dat';

--
-- Data for Name: trecho; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trecho (id, "Data", "origem_país", "Origem _UF", "destino_país", destino_uf, transporte, diarias, missao) FROM stdin;
\.
COPY public.trecho (id, "Data", "origem_país", "Origem _UF", "destino_país", destino_uf, transporte, diarias, missao) FROM '$$PATH$$/2809.dat';

--
-- Data for Name: viagem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.viagem ("Id_processo_ viagem", situacao, orgao_superior, orgao_solicitante, nome, cargo, data_inicio, data_fim, destinos, motivo, valor_diarias, valor_passagens) FROM stdin;
\.
COPY public.viagem ("Id_processo_ viagem", situacao, orgao_superior, orgao_solicitante, nome, cargo, data_inicio, data_fim, destinos, motivo, valor_diarias, valor_passagens) FROM '$$PATH$$/2810.dat';

--
-- PostgreSQL database dump complete
--

